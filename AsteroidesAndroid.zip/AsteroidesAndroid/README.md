# Asteroides — juego Android

Juego arcade 2D nativo para Android, escrito en Kotlin y dibujado directamente con `Canvas` (sin motores ni librerías externas).

## Cómo jugar

- Toca **JUGAR** para comenzar.
- Arrastra el dedo por la parte inferior de la pantalla para mover la nave.
- La nave dispara automáticamente.
- Destruye los asteroides, evita que te golpeen y consigue la mayor puntuación posible.
- Toca el botón de pausa de la esquina superior derecha para detener o reanudar la partida.
- El récord se guarda localmente en el dispositivo.

## Probar sin compilar

Abre `preview.html` en Chrome desde un dispositivo Android para jugar la versión de demostración en el navegador. Esta vista previa funciona como archivo independiente y guarda su récord en el navegador.

## Abrir y ejecutar la app nativa

1. Descomprime `AsteroidesAndroid.zip`.
2. Abre la carpeta `AsteroidesAndroid` desde Android Studio.
3. Deja que Android Studio sincronice el proyecto Gradle.
4. Conecta un teléfono Android con depuración USB o crea un emulador.
5. Pulsa **Run** para instalar y ejecutar la app.

## Configuración

- Paquete: `com.arcade.asteroides`
- Versión: `1.0`
- Android mínimo: Android 6.0 (API 23)
- SDK de compilación: API 35

El proyecto no necesita permisos especiales ni conexión a internet. El APK no se incluye porque este entorno no dispone del SDK de Android ni de Gradle para compilarlo aquí; Android Studio puede generar el APK desde el proyecto.
