package com.arcade.asteroides

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private enum class GameState { READY, PLAYING, PAUSED, GAME_OVER }

private data class Star(var x: Float, var y: Float, val radius: Float, val speed: Float, val alpha: Int)
private data class Bullet(var x: Float, var y: Float, val speed: Float = 760f)
private data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var life: Float,
    val maxLife: Float,
    val radius: Float
)

private class Asteroid(
    var x: Float,
    var y: Float,
    val radius: Float,
    var vx: Float,
    var vy: Float,
    var angle: Float,
    val spin: Float,
    val shape: FloatArray
)

class AsteroidGameView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private fun dp(value: Float) = value * density

    private var gameState = GameState.READY
    private var lifecyclePaused = false
    private var lastFrameNanos = 0L
    private var worldWidth = 0f
    private var worldHeight = 0f
    private var shipX = 0f
    private var shipY = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var score = 0
    private var bestScore = 0
    private var lives = 3
    private var level = 1
    private var spawnClock = 0f
    private var fireClock = 0f
    private var invulnerableClock = 0f
    private var starClock = 0f

    private val stars = mutableListOf<Star>()
    private val asteroids = mutableListOf<Asteroid>()
    private val bullets = mutableListOf<Bullet>()
    private val particles = mutableListOf<Particle>()

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF55E9FF.toInt(); style = Paint.Style.FILL }
    private val shipStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBDF8FF.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(1.8f)
    }
    private val flamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFA24A.toInt(); style = Paint.Style.FILL }
    private val shieldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x9937E7FF.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(2.2f)
    }
    private val asteroidFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF27364C.toInt(); style = Paint.Style.FILL }
    private val asteroidStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8CA4BE.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(2f)
    }
    private val craterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF152236.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(2f)
    }
    private val bulletPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF7AFAFF.toInt(); style = Paint.Style.FILL }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB45F.toInt(); style = Paint.Style.FILL }
    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF0F7FF.toInt(); textSize = dp(16f); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
    }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA7B8CE.toInt(); textSize = dp(11f); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
    }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF5FAFF.toInt(); textSize = dp(31f); textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
    }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFC1D0E2.toInt(); textSize = dp(15f); textAlign = Paint.Align.CENTER
    }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF43E8F8.toInt(); textSize = dp(14f); textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
    }
    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB8050B18.toInt() }
    private val uiStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF41627F.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(1.4f)
    }
    private val buttonFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF10364A.toInt(); style = Paint.Style.FILL }
    private val shipPath = Path()
    private val asteroidPath = Path()
    private val pauseRect = RectF()
    private val prefs = context.getSharedPreferences("asteroid_arcade", Context.MODE_PRIVATE)

    init {
        isFocusable = true
        contentDescription = "Juego Asteroides. Arrastra el dedo para mover la nave y esquivar asteroides."
        bestScore = prefs.getInt("best_score", 0)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        worldWidth = w.toFloat()
        worldHeight = h.toFloat()
        backgroundPaint.shader = LinearGradient(
            0f, 0f, 0f, worldHeight,
            intArrayOf(0xFF07152B.toInt(), 0xFF050B18.toInt(), 0xFF10142B.toInt()),
            null,
            Shader.TileMode.CLAMP
        )
        shipX = worldWidth / 2f
        shipY = worldHeight * 0.82f
        targetX = shipX
        targetY = shipY
        createStars()
    }

    private fun createStars() {
        stars.clear()
        repeat(90) {
            stars += Star(
                Random.nextFloat() * worldWidth,
                Random.nextFloat() * worldHeight,
                dp(Random.nextFloat() * 1.5f + 0.35f),
                dp(Random.nextFloat() * 22f + 12f),
                Random.nextInt(75, 210)
            )
        }
    }

    fun setLifecyclePaused(paused: Boolean) {
        lifecyclePaused = paused
        lastFrameNanos = 0L
        if (!paused) postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (worldWidth <= 0f || worldHeight <= 0f) return
        val now = SystemClock.elapsedRealtimeNanos()
        val dt = if (lastFrameNanos == 0L) 0f else ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0f, 0.04f)
        lastFrameNanos = now

        if (!lifecyclePaused && gameState == GameState.PLAYING) update(dt)
        else if (!lifecyclePaused && gameState == GameState.READY) updateStars(dt * 0.35f)

        drawBackground(canvas)
        drawBullets(canvas)
        drawAsteroids(canvas)
        drawParticles(canvas)
        if (gameState != GameState.GAME_OVER) drawShip(canvas)
        drawHud(canvas)
        drawOverlay(canvas)

        if (isAttachedToWindow && !lifecyclePaused && (gameState == GameState.PLAYING || gameState == GameState.READY)) {
            postInvalidateOnAnimation()
        }
    }

    private fun update(dt: Float) {
        if (dt <= 0f) return
        updateStars(dt)
        starClock += dt
        shipX += (targetX - shipX) * min(1f, dt * 13f)
        shipY += (targetY - shipY) * min(1f, dt * 13f)
        shipX = shipX.coerceIn(dp(24f), worldWidth - dp(24f))
        shipY = shipY.coerceIn(worldHeight * 0.52f, worldHeight * 0.9f)
        invulnerableClock = max(0f, invulnerableClock - dt)

        fireClock += dt
        while (fireClock >= 0.23f) {
            fireClock -= 0.23f
            bullets += Bullet(shipX, shipY - dp(20f), dp(760f))
        }

        spawnClock += dt
        val spawnInterval = (0.98f - (level - 1) * 0.055f).coerceAtLeast(0.34f)
        while (spawnClock >= spawnInterval) {
            spawnClock -= spawnInterval
            spawnAsteroid()
        }

        val bulletIterator = bullets.iterator()
        while (bulletIterator.hasNext()) {
            val bullet = bulletIterator.next()
            bullet.y -= bullet.speed * dt
            if (bullet.y < -dp(24f)) bulletIterator.remove()
        }

        val asteroidIterator = asteroids.iterator()
        while (asteroidIterator.hasNext()) {
            val asteroid = asteroidIterator.next()
            asteroid.x += asteroid.vx * dt
            asteroid.y += asteroid.vy * dt
            asteroid.angle += asteroid.spin * dt
            if (asteroid.x < asteroid.radius || asteroid.x > worldWidth - asteroid.radius) asteroid.vx *= -1f
            if (asteroid.y - asteroid.radius > worldHeight + dp(20f)) asteroidIterator.remove()
        }

        // Projectiles destroy incoming rocks.
        val bulletHits = mutableSetOf<Bullet>()
        val asteroidHits = mutableSetOf<Asteroid>()
        for (bullet in bullets) {
            for (asteroid in asteroids) {
                if (asteroid in asteroidHits) continue
                val dx = bullet.x - asteroid.x
                val dy = bullet.y - asteroid.y
                val hitRadius = asteroid.radius + dp(4f)
                if (dx * dx + dy * dy < hitRadius * hitRadius) {
                    bulletHits += bullet
                    asteroidHits += asteroid
                    score += 10 + (asteroid.radius / dp(10f)).toInt()
                    addExplosion(asteroid.x, asteroid.y, asteroid.radius)
                    break
                }
            }
        }
        bullets.removeAll(bulletHits)
        asteroids.removeAll(asteroidHits)

        // A collision costs one life; a short grace period prevents repeated hits.
        if (invulnerableClock <= 0f) {
            val playerRadius = dp(15f)
            val crash = asteroids.firstOrNull {
                val dx = shipX - it.x
                val dy = shipY - it.y
                val r = playerRadius + it.radius * 0.72f
                dx * dx + dy * dy < r * r
            }
            if (crash != null) {
                asteroids.remove(crash)
                addExplosion(crash.x, crash.y, crash.radius)
                lives -= 1
                invulnerableClock = 1.45f
                if (lives <= 0) finishGame()
            }
        }

        val particleIterator = particles.iterator()
        while (particleIterator.hasNext()) {
            val p = particleIterator.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vx *= 0.985f
            p.vy *= 0.985f
            p.life -= dt
            if (p.life <= 0f) particleIterator.remove()
        }
        level = 1 + score / 180
    }

    private fun updateStars(dt: Float) {
        if (dt <= 0f) return
        for (star in stars) {
            star.y += star.speed * dt
            if (star.y > worldHeight) {
                star.y = 0f
                star.x = Random.nextFloat() * worldWidth
            }
        }
    }

    private fun spawnAsteroid() {
        val radius = dp(Random.nextFloat() * 17f + 19f)
        val x = Random.nextFloat() * (worldWidth - 2f * radius) + radius
        val speed = dp(Random.nextFloat() * 75f + 115f + (level - 1) * 10f)
        val shape = FloatArray(10) { index -> Random.nextFloat() * 0.28f + 0.82f }
        asteroids += Asteroid(
            x = x,
            y = -radius,
            radius = radius,
            vx = dp(Random.nextFloat() * 65f - 32f),
            vy = speed,
            angle = Random.nextFloat() * 360f,
            spin = Random.nextFloat() * 100f - 50f,
            shape = shape
        )
    }

    private fun addExplosion(x: Float, y: Float, radius: Float) {
        repeat(12) {
            val angle = Random.nextFloat() * (Math.PI * 2.0).toFloat()
            val speed = dp(Random.nextFloat() * 150f + 35f)
            val life = Random.nextFloat() * 0.35f + 0.28f
            particles += Particle(
                x, y,
                cos(angle) * speed,
                sin(angle) * speed,
                life, life,
                dp(Random.nextFloat() * 2.6f + 1.3f)
            )
        }
    }

    private fun finishGame() {
        gameState = GameState.GAME_OVER
        if (score > bestScore) {
            bestScore = score
            prefs.edit().putInt("best_score", bestScore).apply()
        }
    }

    private fun startGame() {
        score = 0
        lives = 3
        level = 1
        spawnClock = 0f
        fireClock = 0f
        invulnerableClock = 0f
        asteroids.clear()
        bullets.clear()
        particles.clear()
        shipX = worldWidth / 2f
        shipY = worldHeight * 0.82f
        targetX = shipX
        targetY = shipY
        gameState = GameState.PLAYING
        lastFrameNanos = 0L
        postInvalidateOnAnimation()
    }

    private fun drawBackground(canvas: Canvas) {
        canvas.drawRect(0f, 0f, worldWidth, worldHeight, backgroundPaint)
        for (star in stars) {
            starPaint.color = (star.alpha shl 24) or 0x00D8F2FF
            canvas.drawCircle(star.x, star.y, star.radius, starPaint)
        }
    }

    private fun drawShip(canvas: Canvas) {
        if (invulnerableClock > 0f && (invulnerableClock * 12f).toInt() % 2 == 0) return
        val size = dp(22f)
        val flameLength = dp(9f + (sin(starClock * 18f) * 3f))
        shipPath.reset()
        shipPath.moveTo(shipX, shipY - size)
        shipPath.lineTo(shipX + size * 0.76f, shipY + size * 0.72f)
        shipPath.lineTo(shipX, shipY + size * 0.34f)
        shipPath.lineTo(shipX - size * 0.76f, shipY + size * 0.72f)
        shipPath.close()
        canvas.drawOval(shipX - dp(5f), shipY + size * 0.53f, shipX + dp(5f), shipY + size * 0.53f + flameLength, flamePaint)
        canvas.drawPath(shipPath, shipPaint)
        canvas.drawPath(shipPath, shipStroke)
        canvas.drawCircle(shipX, shipY + dp(1f), dp(4f), bulletPaint)
        if (invulnerableClock > 0f) canvas.drawCircle(shipX, shipY, dp(31f), shieldPaint)
    }

    private fun drawBullets(canvas: Canvas) {
        for (bullet in bullets) {
            canvas.drawRoundRect(
                bullet.x - dp(2f), bullet.y - dp(8f), bullet.x + dp(2f), bullet.y + dp(8f),
                dp(2f), dp(2f), bulletPaint
            )
        }
    }

    private fun drawAsteroids(canvas: Canvas) {
        for (asteroid in asteroids) {
            asteroidPath.reset()
            for (i in asteroid.shape.indices) {
                val angle = (i.toFloat() / asteroid.shape.size) * (Math.PI * 2.0).toFloat()
                val radius = asteroid.radius * asteroid.shape[i]
                val px = cos(angle) * radius
                val py = sin(angle) * radius
                if (i == 0) asteroidPath.moveTo(px, py) else asteroidPath.lineTo(px, py)
            }
            asteroidPath.close()
            canvas.save()
            canvas.translate(asteroid.x, asteroid.y)
            canvas.rotate(asteroid.angle)
            canvas.drawPath(asteroidPath, asteroidFill)
            canvas.drawPath(asteroidPath, asteroidStroke)
            canvas.drawCircle(-asteroid.radius * 0.28f, -asteroid.radius * 0.13f, asteroid.radius * 0.17f, craterPaint)
            canvas.drawCircle(asteroid.radius * 0.25f, asteroid.radius * 0.27f, asteroid.radius * 0.11f, craterPaint)
            canvas.restore()
        }
    }

    private fun drawParticles(canvas: Canvas) {
        for (particle in particles) {
            val alpha = (255f * (particle.life / particle.maxLife).coerceIn(0f, 1f)).toInt()
            particlePaint.alpha = alpha
            canvas.drawCircle(particle.x, particle.y, particle.radius, particlePaint)
        }
        particlePaint.alpha = 255
    }

    private fun drawHud(canvas: Canvas) {
        if (gameState == GameState.READY) return
        val margin = dp(20f)
        smallPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("PUNTOS", margin, dp(35f), smallPaint)
        canvas.drawText(score.toString(), margin, dp(57f), hudPaint)
        smallPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("NIVEL $level", worldWidth / 2f, dp(35f), smallPaint)
        canvas.drawText("VIDAS  ${"♥ ".repeat(lives).trim()}", worldWidth / 2f, dp(57f), hudPaint)
        pauseRect.set(worldWidth - dp(58f), dp(15f), worldWidth - dp(18f), dp(55f))
        canvas.drawRoundRect(pauseRect, dp(12f), dp(12f), buttonFill)
        canvas.drawRoundRect(pauseRect, dp(12f), dp(12f), uiStroke)
        val midX = pauseRect.centerX()
        val midY = pauseRect.centerY()
        if (gameState == GameState.PAUSED) {
            val p = Path().apply {
                moveTo(midX - dp(4f), midY - dp(7f)); lineTo(midX + dp(7f), midY); lineTo(midX - dp(4f), midY + dp(7f)); close()
            }
            canvas.drawPath(p, shipPaint)
        } else {
            canvas.drawRoundRect(midX - dp(6f), midY - dp(7f), midX - dp(2f), midY + dp(7f), dp(1f), dp(1f), shipPaint)
            canvas.drawRoundRect(midX + dp(2f), midY - dp(7f), midX + dp(6f), midY + dp(7f), dp(1f), dp(1f), shipPaint)
        }
    }

    private fun drawOverlay(canvas: Canvas) {
        when (gameState) {
            GameState.READY -> {
                canvas.drawRect(0f, 0f, worldWidth, worldHeight, overlayPaint)
                canvas.drawText("ASTEROIDES", worldWidth / 2f, worldHeight * 0.34f, titlePaint)
                accentPaint.textSize = dp(13f)
                canvas.drawText("DEFENDE LA GALAXIA", worldWidth / 2f, worldHeight * 0.34f + dp(30f), accentPaint)
                drawStartButton(canvas, worldHeight * 0.59f, "JUGAR")
                bodyPaint.textSize = dp(14f)
                canvas.drawText("Arrastra el dedo para mover la nave", worldWidth / 2f, worldHeight * 0.72f, bodyPaint)
                canvas.drawText("Disparas automáticamente. ¡No te choques!", worldWidth / 2f, worldHeight * 0.72f + dp(25f), bodyPaint)
                if (bestScore > 0) {
                    smallPaint.textAlign = Paint.Align.CENTER
                    canvas.drawText("RÉCORD  $bestScore", worldWidth / 2f, worldHeight * 0.83f, smallPaint)
                }
            }
            GameState.PAUSED -> {
                canvas.drawRect(0f, 0f, worldWidth, worldHeight, overlayPaint)
                canvas.drawText("PAUSA", worldWidth / 2f, worldHeight * 0.43f, titlePaint)
                drawStartButton(canvas, worldHeight * 0.57f, "SEGUIR")
                canvas.drawText("Toca para continuar", worldWidth / 2f, worldHeight * 0.68f, bodyPaint)
            }
            GameState.GAME_OVER -> {
                canvas.drawRect(0f, 0f, worldWidth, worldHeight, overlayPaint)
                canvas.drawText("FIN DEL JUEGO", worldWidth / 2f, worldHeight * 0.39f, titlePaint)
                accentPaint.textSize = dp(16f)
                canvas.drawText("PUNTUACIÓN  $score", worldWidth / 2f, worldHeight * 0.47f, accentPaint)
                bodyPaint.textSize = dp(14f)
                canvas.drawText("RÉCORD  $bestScore", worldWidth / 2f, worldHeight * 0.52f, bodyPaint)
                drawStartButton(canvas, worldHeight * 0.63f, "VOLVER A JUGAR")
                canvas.drawText("Toca la pantalla para intentarlo otra vez", worldWidth / 2f, worldHeight * 0.76f, bodyPaint)
            }
            GameState.PLAYING -> Unit
        }
    }

    private fun drawStartButton(canvas: Canvas, centerY: Float, label: String) {
        val rect = RectF(worldWidth / 2f - dp(112f), centerY - dp(27f), worldWidth / 2f + dp(112f), centerY + dp(27f))
        canvas.drawRoundRect(rect, dp(18f), dp(18f), buttonFill)
        canvas.drawRoundRect(rect, dp(18f), dp(18f), uiStroke)
        accentPaint.textSize = dp(14f)
        canvas.drawText(label, worldWidth / 2f, centerY + dp(5f), accentPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val x = event.x
                val y = event.y
                when (gameState) {
                    GameState.READY, GameState.GAME_OVER -> {
                        if (event.actionMasked == MotionEvent.ACTION_DOWN) startGame()
                    }
                    GameState.PAUSED -> {
                        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                            gameState = GameState.PLAYING
                            lastFrameNanos = 0L
                        }
                    }
                    GameState.PLAYING -> {
                        if (event.actionMasked == MotionEvent.ACTION_DOWN && x > worldWidth - dp(72f) && y < dp(72f)) {
                            gameState = GameState.PAUSED
                        } else {
                            targetX = x.coerceIn(dp(24f), worldWidth - dp(24f))
                            targetY = y.coerceIn(worldHeight * 0.52f, worldHeight * 0.9f)
                        }
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }
}
